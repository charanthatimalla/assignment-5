const express = require('express')
const app = express()
const port = 3000
const path = require('path')

const data = {
  customers: [
    { id: 1, name: 'John Snow' },
    { id: 2, name: 'Troy Deany' },
    { id: 3, name: 'Rick Noah' },
    { id: 4, name: 'Alice Chen' },
    { id: 5, name: 'Bob Lee' }
  ],
  orders: [
    { id: 1, customerId: 1, item: 'Walkman' },
    { id: 2, customerId: 1, item: 'Shin Guards' },
    { id: 3, customerId: 2, item: 'Violin' },
    { id: 4, customerId: 3, item: 'Safebox' },
    { id: 5, customerId: 4, item: 'Laptop' },
    { id: 6, customerId: 4, item: 'Smartphone' },
    { id: 7, customerId: 5, item: 'Camera' },
    { id: 8, customerId: 5, item: 'Headphones' }
  ]
};

// Route handler for the customers collection
app.get('/customers', (req, res) => {
  res.json(data.customers)
})

// Route handler for a single customer record
app.get('/customers/:id', (req, res) => {
  const id = parseInt(req.params.id)
  const customer = data.customers.find(c => c.id === id)
  if (!customer) {
    res.sendStatus(404)
  } else {
    res.json(customer)
  }
})

// Route handler for orders collection for a given customer
app.get('/customers/:id/orders', (req, res) => {
  const id = parseInt(req.params.id)
  const orders = data.orders.filter(o => o.customerId === id)
  res.json(orders)
})

// Route handler for a single order record for a given customer
app.get('/customers/:id/orders/:orderId', (req, res) => {
  const id = parseInt(req.params.id)
  const orderId = parseInt(req.params.orderId)
  const orders = data.orders.filter(o => o.customerId === id)
  const order = orders.find(o => o.id === orderId)
  if (!order) {
    res.sendStatus(404)
  } else {
    res.json(order)
  }
})

// Serve the index.html file as the default page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'))
})

// Start the web service
app.listen(port, () => {
  console.log(`Web service listening at http://localhost:${port}`)
})